/**
 * Cliente SOAP manual para library_soap_service (Parte 8 del ejercicio
 * guiado). Construye el soap:Envelope con DOMParser/document.implementation
 * (disponibles en el renderer por ser un contexto de navegador) y procesa
 * tanto la respuesta normal como un soap:Fault, sin exponer a la GUI
 * ningun detalle de PostgreSQL.
 *
 * Organizado en 3 partes:
 *   1) Construccion de Envelopes (uno por operacion).
 *   2) Envio (via window.soapApi, que corre en el proceso principal).
 *   3) Lectura de la respuesta / SOAP Fault.
 */

const SOAP_NS = "http://schemas.xmlsoap.org/soap/envelope/";
const TNS = "urn:udem:iac:library-classifier";

// Identifica a esta app frente al modulo SOAP para el conteo de
// "clientes_servidos" (header opcional ClienteInfo, ver soap/service.py).
const TIPO_CLIENTE = "electron-desktop";

function idIdentificadorCliente() {
  // Un identificador estable por instalacion, guardado en localStorage.
  const CLAVE = "soapClient.identificador";
  let id = localStorage.getItem(CLAVE);
  if (!id) {
    id = `equipo-${Math.random().toString(36).slice(2, 10)}`;
    localStorage.setItem(CLAVE, id);
  }
  return id;
}

/** Arma el soap:Header opcional con ClienteInfo. */
function construirHeaderClienteInfo() {
  return `
  <soap:Header>
    <tns:ClienteInfo>
      <tns:tipoCliente>${TIPO_CLIENTE}</tns:tipoCliente>
      <tns:identificador>${idIdentificadorCliente()}</tns:identificador>
    </tns:ClienteInfo>
  </soap:Header>`;
}

/**
 * A diferencia del servidor (que arma XML con ElementTree, que escapa
 * automaticamente), aqui se arma con template strings, asi que cada valor
 * que viene del usuario debe escaparse a mano antes de insertarse.
 */
function escaparXml(valor) {
  return String(valor)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function envolver(cuerpoOperacion, headerExtra = "") {
  return `<?xml version="1.0" encoding="UTF-8"?>
<soap:Envelope xmlns:soap="${SOAP_NS}" xmlns:tns="${TNS}">${headerExtra}
  <soap:Body>
    ${cuerpoOperacion}
  </soap:Body>
</soap:Envelope>`;
}

// ---------------------------------------------------------------------
// 1) Un constructor de Envelope por operacion del contrato WSDL
// ---------------------------------------------------------------------

function envelopeObtenerConceptosPendientes(correo) {
  const cuerpo = `<tns:ObtenerConceptosPendientesRequest>
      <tns:correoClasificador>${escaparXml(correo)}</tns:correoClasificador>
    </tns:ObtenerConceptosPendientesRequest>`;
  return envolver(cuerpo, construirHeaderClienteInfo());
}

function envelopeRegistrarClasificacion({ nombre, apellido, correo, isbn, idConcepto, modeloCloud }) {
  const cuerpo = `<tns:RegistrarClasificacionRequest>
      <tns:nombre>${escaparXml(nombre)}</tns:nombre>
      <tns:apellido>${escaparXml(apellido)}</tns:apellido>
      <tns:correo>${escaparXml(correo)}</tns:correo>
      <tns:isbn>${escaparXml(isbn)}</tns:isbn>
      <tns:idConcepto>${escaparXml(idConcepto)}</tns:idConcepto>
      <tns:modeloCloud>${escaparXml(modeloCloud)}</tns:modeloCloud>
      <tns:origenCliente>${TIPO_CLIENTE}</tns:origenCliente>
    </tns:RegistrarClasificacionRequest>`;
  return envolver(cuerpo, construirHeaderClienteInfo());
}

function envelopeObtenerProgresoUsuario(correo) {
  const cuerpo = `<tns:ObtenerProgresoUsuarioRequest>
      <tns:correo>${escaparXml(correo)}</tns:correo>
    </tns:ObtenerProgresoUsuarioRequest>`;
  return envolver(cuerpo, construirHeaderClienteInfo());
}

// ---------------------------------------------------------------------
// 2) Envio + 3) lectura de respuesta / Fault
// ---------------------------------------------------------------------

/**
 * Envia el Envelope y devuelve SIEMPRE un objeto homogeneo:
 *   { ok: true,  datos: <resultado ya convertido a JS> }
 *   { ok: false, codigo, mensaje }  (viene de un soap:Fault, o de un
 *                                    problema de red/servidor)
 * La GUI nunca necesita saber si el problema fue SQL, red o validacion:
 * solo usa `mensaje` (ya pensado para mostrarse tal cual al usuario).
 */
async function invocarOperacion(endpointUrl, envelopeXml, extraerRespuesta) {
  let resultado;
  try {
    resultado = await window.soapApi.invocar(endpointUrl, envelopeXml);
  } catch (err) {
    return { ok: false, codigo: "ERROR_RED", mensaje: `No se pudo contactar el modulo SOAP: ${err.message}` };
  }

  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(resultado.xml, "application/xml");
  if (xmlDoc.querySelector("parsererror")) {
    return { ok: false, codigo: "XML_INVALIDO", mensaje: "El modulo SOAP devolvio un XML invalido." };
  }

  const fault = xmlDoc.getElementsByTagNameNS(SOAP_NS, "Fault")[0];
  if (fault) {
    const mensaje = fault.getElementsByTagName("faultstring")[0]?.textContent || "Error no especificado.";
    const codigo = fault.getElementsByTagNameNS(TNS, "codigo")[0]?.textContent || "DESCONOCIDO";
    return { ok: false, codigo, mensaje };
  }

  return { ok: true, datos: extraerRespuesta(xmlDoc) };
}

function textoHijo(elemento, tag) {
  return elemento.getElementsByTagNameNS(TNS, tag)[0]?.textContent ?? "";
}

async function obtenerConceptosPendientes(endpointUrl, correo) {
  const xml = envelopeObtenerConceptosPendientes(correo);
  return invocarOperacion(endpointUrl, xml, (xmlDoc) => {
    const nodos = Array.from(xmlDoc.getElementsByTagNameNS(TNS, "conceptoPendiente"));
    return nodos.map((n) => ({
      isbn: textoHijo(n, "isbn"),
      tituloLibro: textoHijo(n, "tituloLibro"),
      idConcepto: textoHijo(n, "idConcepto"),
      nombreConcepto: textoHijo(n, "nombreConcepto"),
      definicion: textoHijo(n, "definicion"),
      categorias: textoHijo(n, "categorias"),
    }));
  });
}

async function registrarClasificacion(endpointUrl, datos) {
  const xml = envelopeRegistrarClasificacion(datos);
  return invocarOperacion(endpointUrl, xml, (xmlDoc) => {
    const respuesta = xmlDoc.getElementsByTagNameNS(TNS, "RegistrarClasificacionResponse")[0];
    return {
      idClasificacion: textoHijo(respuesta, "idClasificacion"),
      mensaje: textoHijo(respuesta, "mensaje"),
    };
  });
}

async function obtenerProgresoUsuario(endpointUrl, correo) {
  const xml = envelopeObtenerProgresoUsuario(correo);
  return invocarOperacion(endpointUrl, xml, (xmlDoc) => {
    const respuesta = xmlDoc.getElementsByTagNameNS(TNS, "ObtenerProgresoUsuarioResponse")[0];
    return {
      totalConceptos: textoHijo(respuesta, "totalConceptos"),
      totalClasificados: textoHijo(respuesta, "totalClasificados"),
      totalPendientes: textoHijo(respuesta, "totalPendientes"),
    };
  });
}
