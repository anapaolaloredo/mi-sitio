/**
 * Puente seguro entre el renderer (sin acceso directo a Node/Electron) y el
 * proceso principal. Expone: (1) pedir el XML de temas de libros al
 * microservicio REST-XML en la nube, y (2) invocar el modulo SOAP de
 * clasificacion (library_soap_service).
 */
const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("libraryApi", {
  /**
   * @param {string} baseUrl URL base del microservicio en la nube, p.ej. http://IP:5001
   * @param {string} [isbn] filtro opcional por ISBN exacto
   * @returns {Promise<string>} el cuerpo XML de la respuesta
   */
  obtenerTemas: (baseUrl, isbn) =>
    ipcRenderer.invoke("libros:obtener-temas", { baseUrl, isbn }),
});

contextBridge.exposeInMainWorld("soapApi", {
  /**
   * @param {string} endpointUrl URL del endpoint SOAP, p.ej. http://IP:5002/soap
   * @param {string} envelopeXml el soap:Envelope completo, ya armado por el renderer
   * @returns {Promise<{status: number, xml: string}>}
   */
  invocar: (endpointUrl, envelopeXml) =>
    ipcRenderer.invoke("soap:invocar", { endpointUrl, envelopeXml }),
});
