/**
 * Proceso principal de Electron.
 *
 * Punto clave sobre CORS: el microservicio (apps/services/soap/app.py) corre
 * en una instancia en la nube, mientras esta app corre en la maquina local.
 * Si la peticion HTTP se hiciera desde el renderer (la pagina web dentro de
 * Electron, que es Chromium), estaria sujeta a las mismas restricciones CORS
 * que un navegador. Para evitar depender de la politica CORS del servidor,
 * la peticion se hace aqui, en el proceso principal (Node.js puro), que NO
 * aplica CORS. El renderer solo recibe el XML ya descargado via IPC.
 */

const { app, BrowserWindow, ipcMain } = require("electron");
const path = require("path");
const http = require("http");
const https = require("https");

function createWindow() {
  const win = new BrowserWindow({
    width: 960,
    height: 720,
    webPreferences: {
      // Seguridad recomendada por Electron: el renderer no toca Node directo,
      // solo lo que exponemos explicitamente en preload.js.
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });
  win.loadFile("index.html");
}

app.whenReady().then(createWindow);

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

/**
 * Descarga el contenido de una URL exigiendo explicitamente XML
 * (Accept: application/xml). La app consume unicamente este formato,
 * nunca JSON, tal como pide el microservicio de libros.
 */
function httpGetXml(urlString) {
  return new Promise((resolve, reject) => {
    let target;
    try {
      target = new URL(urlString);
    } catch {
      reject(new Error(`URL invalida: ${urlString}`));
      return;
    }

    const client = target.protocol === "https:" ? https : http;
    const req = client.get(
      target,
      { headers: { Accept: "application/xml" } },
      (res) => {
        let body = "";
        res.setEncoding("utf8");
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(body);
          } else {
            reject(
              new Error(
                `El microservicio respondio con estado ${res.statusCode}: ${body}`
              )
            );
          }
        });
      }
    );

    req.on("error", (err) => reject(err));
    req.setTimeout(10000, () => {
      req.destroy(new Error("Tiempo de espera agotado al contactar el microservicio"));
    });
  });
}

// Canal IPC usado por el renderer (a traves de preload.js) para pedir
// "nombre de libro, isbn, temas y descripcion de cada tema" al endpoint
// GET /api/libros/temas del microservicio.
ipcMain.handle("libros:obtener-temas", async (_event, { baseUrl, isbn }) => {
  const url = new URL("/api/libros/temas", baseUrl);
  if (isbn) url.searchParams.set("isbn", isbn);
  return httpGetXml(url.toString());
});

/**
 * Envia un SOAP Envelope (texto XML ya armado por el renderer) por HTTP
 * POST al modulo SOAP (library_soap_service). Igual que httpGetXml, corre
 * en el proceso principal para no depender de CORS. Nunca lanza en caso
 * de HTTP 4xx/5xx: el modulo SOAP responde SIEMPRE un cuerpo XML (una
 * respuesta normal o un soap:Fault), y es el renderer quien decide como
 * interpretarlo. Solo se rechaza la promesa ante errores de red/timeout.
 */
function httpPostXml(urlString, envelopeXml) {
  return new Promise((resolve, reject) => {
    let target;
    try {
      target = new URL(urlString);
    } catch {
      reject(new Error(`URL invalida: ${urlString}`));
      return;
    }

    const cuerpo = Buffer.from(envelopeXml, "utf-8");
    const client = target.protocol === "https:" ? https : http;
    const req = client.request(
      target,
      {
        method: "POST",
        headers: {
          "Content-Type": "text/xml; charset=utf-8",
          "Content-Length": cuerpo.length,
        },
      },
      (res) => {
        let body = "";
        res.setEncoding("utf8");
        res.on("data", (chunk) => (body += chunk));
        res.on("end", () => {
          resolve({ status: res.statusCode, xml: body });
        });
      }
    );

    req.on("error", (err) => reject(err));
    req.setTimeout(10000, () => {
      req.destroy(new Error("Tiempo de espera agotado al contactar el modulo SOAP"));
    });
    req.write(cuerpo);
    req.end();
  });
}

// Canal IPC para invocar cualquier operacion del modulo SOAP: el renderer
// arma el Envelope completo (ver soapClient.js) y aqui solo se transporta.
ipcMain.handle("soap:invocar", async (_event, { endpointUrl, envelopeXml }) => {
  return httpPostXml(endpointUrl, envelopeXml);
});
