/**
 * Renderer: logica de la interfaz.
 *
 * Este archivo se ejecuta en el proceso de renderizado (contexto de
 * navegador dentro de Electron). No tiene acceso a Node ni a red directa:
 * usa `window.libraryApi` (expuesto por preload.js) para pedirle al
 * proceso principal que descargue el XML del microservicio.
 *
 * El archivo esta organizado en 3 bloques independientes:
 *   1) Reglas de clasificacion cloud (una funcion por categoria).
 *   2) Utilidades para leer el XML del microservicio.
 *   3) Manejo del formulario y render de resultados.
 */

// ---------------------------------------------------------------------
// 1) Reglas de clasificacion (palabras clave + expresiones regulares)
// ---------------------------------------------------------------------
// Cada categoria vive en su propia constante/funcion para que agregar o
// afinar palabras clave de una categoria no afecte a las demas.

const IAAS_KEYWORDS = [
  "infraestructura",
  "maquina virtual",
  "máquina virtual",
  "servidor virtual",
  "virtual machine",
  "hipervisor",
  "red virtual",
  "almacenamiento en bloque",
  "balanceador de carga",
  "bare metal",
  "centro de datos",
  "data center",
];
const IAAS_REGEX =
  /\biaas\b|\binfraestructura\s+como\s+servicio\b|\bm[aá]quinas?\s+virtuales?\b|\bvirtual\s+machines?\b|\bhipervisor(es)?\b/i;

const PAAS_KEYWORDS = [
  "plataforma",
  "entorno de desarrollo",
  "despliegue de aplicaciones",
  "heroku",
  "app engine",
  "elastic beanstalk",
  "middleware",
  "entorno gestionado",
  "base de datos gestionada",
];
const PAAS_REGEX =
  /\bpaas\b|\bplataforma\s+como\s+servicio\b|\bheroku\b|\bapp\s+engine\b|\belastic\s+beanstalk\b/i;

const SAAS_KEYWORDS = [
  "software como servicio",
  "suscripcion",
  "suscripción",
  "office 365",
  "salesforce",
  "dropbox",
  "gmail",
  "aplicacion web lista para usar",
  "aplicación web lista para usar",
  "multitenencia",
];
const SAAS_REGEX =
  /\bsaas\b|\bsoftware\s+como\s+servicio\b|\bsuscripci[oó]n(es)?\b|\bmultitenencia\b/i;

const FAAS_KEYWORDS = [
  "funcion como servicio",
  "función como servicio",
  "serverless",
  "sin servidor",
  "lambda",
  "azure functions",
  "cloud functions",
  "pago por ejecucion",
  "pago por ejecución",
  "computo efimero",
  "cómputo efímero",
  "disparado por eventos",
];
const FAAS_REGEX =
  /\bfaas\b|\bserverless\b|\bsin\s+servidor\b|\blambda\b|\bazure\s+functions\b|\bcloud\s+functions\b|\bfunci[oó]n(es)?\s+como\s+servicio\b/i;

/** Cuenta cuantas palabras clave de la lista aparecen en el texto (minusculas). */
function contarCoincidenciasDeLista(textoLower, listaPalabras) {
  return listaPalabras.filter((palabra) => textoLower.includes(palabra)).length;
}

/** Analiza el texto y puntua que tan "IaaS" es. */
function clasificarIaas(texto) {
  const textoLower = texto.toLowerCase();
  const hitsPalabras = contarCoincidenciasDeLista(textoLower, IAAS_KEYWORDS);
  const hitRegex = IAAS_REGEX.test(texto) ? 1 : 0;
  return { categoria: "IaaS", puntaje: hitsPalabras + hitRegex };
}

/** Analiza el texto y puntua que tan "PaaS" es. */
function clasificarPaas(texto) {
  const textoLower = texto.toLowerCase();
  const hitsPalabras = contarCoincidenciasDeLista(textoLower, PAAS_KEYWORDS);
  const hitRegex = PAAS_REGEX.test(texto) ? 1 : 0;
  return { categoria: "PaaS", puntaje: hitsPalabras + hitRegex };
}

/** Analiza el texto y puntua que tan "SaaS" es. */
function clasificarSaas(texto) {
  const textoLower = texto.toLowerCase();
  const hitsPalabras = contarCoincidenciasDeLista(textoLower, SAAS_KEYWORDS);
  const hitRegex = SAAS_REGEX.test(texto) ? 1 : 0;
  return { categoria: "SaaS", puntaje: hitsPalabras + hitRegex };
}

/** Analiza el texto y puntua que tan "FaaS" es. */
function clasificarFaas(texto) {
  const textoLower = texto.toLowerCase();
  const hitsPalabras = contarCoincidenciasDeLista(textoLower, FAAS_KEYWORDS);
  const hitRegex = FAAS_REGEX.test(texto) ? 1 : 0;
  return { categoria: "FaaS", puntaje: hitsPalabras + hitRegex };
}

/**
 * Corre las 4 reglas y decide la categoria principal (mayor puntaje).
 * Si ninguna regla obtuvo coincidencias, se reporta "No determinado".
 */
function clasificarTexto(texto) {
  const resultados = [
    clasificarIaas(texto),
    clasificarPaas(texto),
    clasificarSaas(texto),
    clasificarFaas(texto),
  ];
  const mejor = resultados.reduce((max, actual) =>
    actual.puntaje > max.puntaje ? actual : max
  );
  const huboCoincidencias = mejor.puntaje > 0;
  return {
    resultados,
    ganador: huboCoincidencias ? mejor.categoria : "No determinado",
  };
}

// ---------------------------------------------------------------------
// 2) Lectura del XML devuelto por el microservicio
// ---------------------------------------------------------------------

/**
 * Convierte el XML de GET /api/libros/temas en un arreglo de objetos JS:
 * [{ isbn, title, topics: [{ name, description }] }]
 * Se usa DOMParser (disponible en el renderer por ser un contexto de
 * navegador) para no depender de ninguna libreria externa.
 */
function parsearTemasXml(xmlTexto) {
  const parser = new DOMParser();
  const xmlDoc = parser.parseFromString(xmlTexto, "application/xml");

  if (xmlDoc.querySelector("parsererror")) {
    throw new Error("El microservicio devolvio un XML invalido.");
  }

  const nodoError = xmlDoc.querySelector("error > message");
  if (nodoError) {
    throw new Error(nodoError.textContent);
  }

  const nodosLibro = Array.from(xmlDoc.getElementsByTagName("book"));
  return nodosLibro.map((nodoLibro) => {
    const isbn = nodoLibro.getAttribute("isbn") || "";
    const title = nodoLibro.getElementsByTagName("title")[0]?.textContent || "";
    const topics = Array.from(nodoLibro.getElementsByTagName("topic")).map(
      (nodoTema) => ({
        name: nodoTema.getAttribute("name") || "",
        description:
          nodoTema.getElementsByTagName("description")[0]?.textContent || "",
      })
    );
    return { isbn, title, topics };
  });
}

/**
 * Busca, dentro de los libros obtenidos del microservicio, los temas cuyo
 * nombre o descripcion coincidan con las palabras clave / regex de la
 * categoria detectada, para mostrarlos como contexto en la interfaz.
 */
function buscarTemasRelacionados(libros, categoria) {
  const reglasPorCategoria = {
    IaaS: { palabras: IAAS_KEYWORDS, regex: IAAS_REGEX },
    PaaS: { palabras: PAAS_KEYWORDS, regex: PAAS_REGEX },
    SaaS: { palabras: SAAS_KEYWORDS, regex: SAAS_REGEX },
    FaaS: { palabras: FAAS_KEYWORDS, regex: FAAS_REGEX },
  };
  const reglas = reglasPorCategoria[categoria];
  if (!reglas) return [];

  const relacionados = [];
  for (const libro of libros) {
    for (const tema of libro.topics) {
      const textoTema = `${tema.name} ${tema.description}`.toLowerCase();
      const coincidePalabra = contarCoincidenciasDeLista(textoTema, reglas.palabras) > 0;
      const coincideRegex = reglas.regex.test(textoTema);
      if (coincidePalabra || coincideRegex) {
        relacionados.push({ libro: libro.title, isbn: libro.isbn, tema: tema.name, descripcion: tema.description });
      }
    }
  }
  return relacionados;
}

// ---------------------------------------------------------------------
// 3) Interfaz: formulario, llamada al microservicio y render
// ---------------------------------------------------------------------

const CLAVE_LOCALSTORAGE_URL = "clasificador.baseUrl";

function mostrarError(mensaje) {
  const box = document.getElementById("errorBox");
  box.textContent = mensaje;
  box.style.display = mensaje ? "block" : "none";
}

function claseBadgePara(categoria) {
  switch (categoria) {
    case "IaaS":
      return "badge-iaas";
    case "PaaS":
      return "badge-paas";
    case "SaaS":
      return "badge-saas";
    case "FaaS":
      return "badge-faas";
    default:
      return "badge-none";
  }
}

function renderResultado({ nombre, apellido, resultados, ganador }) {
  const saludo = document.getElementById("saludo");
  const categoriaEl = document.getElementById("categoriaDetectada");
  const puntajesEl = document.getElementById("puntajes");

  saludo.textContent = `${nombre} ${apellido}, el texto se clasifica principalmente como:`;

  categoriaEl.textContent = ganador;
  categoriaEl.className = "categoria " + claseBadgePara(ganador);

  puntajesEl.innerHTML = "";
  for (const r of resultados) {
    const span = document.createElement("span");
    span.textContent = `${r.categoria}: ${r.puntaje} coincidencia(s)`;
    puntajesEl.appendChild(span);
  }

  document.getElementById("resultado").style.display = "block";
}

function renderRelacionados(relacionados) {
  const contenedor = document.getElementById("relacionados");
  const lista = document.getElementById("listaRelacionados");
  lista.innerHTML = "";

  if (relacionados.length === 0) {
    contenedor.style.display = "none";
    return;
  }

  for (const item of relacionados) {
    const li = document.createElement("li");
    li.textContent = `${item.libro} (ISBN ${item.isbn}) — ${item.tema}: ${item.descripcion}`;
    lista.appendChild(li);
  }
  contenedor.style.display = "block";
}

async function alEnviarFormulario() {
  mostrarError("");

  const baseUrl = document.getElementById("baseUrl").value.trim();
  const nombre = document.getElementById("nombre").value.trim();
  const apellido = document.getElementById("apellido").value.trim();
  const texto = document.getElementById("texto").value.trim();

  if (!nombre || !apellido || !texto) {
    mostrarError("Completa nombre, apellido y el texto a analizar.");
    return;
  }
  if (!baseUrl) {
    mostrarError("Indica la URL del microservicio en la nube.");
    return;
  }

  localStorage.setItem(CLAVE_LOCALSTORAGE_URL, baseUrl);

  const boton = document.getElementById("btnAnalizar");
  boton.disabled = true;
  boton.textContent = "Analizando...";

  try {
    // Paso 1: clasificacion local del texto escrito por el usuario.
    const { resultados, ganador } = clasificarTexto(texto);
    renderResultado({ nombre, apellido, resultados, ganador });

    // Paso 2: consumo del microservicio (exclusivamente XML) para dar
    // contexto con temas de la biblioteca relacionados a la categoria.
    const xml = await window.libraryApi.obtenerTemas(baseUrl);
    const libros = parsearTemasXml(xml);
    const relacionados = buscarTemasRelacionados(libros, ganador);
    renderRelacionados(relacionados);
  } catch (err) {
    mostrarError(`No se pudo consultar el microservicio: ${err.message}`);
  } finally {
    boton.disabled = false;
    boton.textContent = "Analizar texto";
  }
}

// ---------------------------------------------------------------------
// 4) Modo cliente SOAP (Parte 8 del ejercicio guiado)
// ---------------------------------------------------------------------
// Guarda el ultimo resultado de clasificacion local para poder registrarlo
// via SOAP sin volver a correr las reglas de clasificacion.
let ultimaClasificacion = null;
let conceptoSeleccionado = null;

const CLAVE_LOCALSTORAGE_SOAP = "clasificador.soapEndpoint";

function mostrarSoapFault(mensaje) {
  const el = document.getElementById("soapFault");
  const ok = document.getElementById("soapOk");
  ok.style.display = "none";
  el.textContent = mensaje;
  el.style.display = mensaje ? "block" : "none";
}

function mostrarSoapOk(mensaje) {
  const el = document.getElementById("soapOk");
  const fault = document.getElementById("soapFault");
  fault.style.display = "none";
  el.textContent = mensaje;
  el.style.display = mensaje ? "block" : "none";
}

function renderConceptosPendientes(lista) {
  const contenedor = document.getElementById("listaPendientes");
  contenedor.innerHTML = "";
  conceptoSeleccionado = null;
  document.getElementById("btnRegistrarSoap").style.display = "none";

  if (lista.length === 0) {
    contenedor.textContent = "No hay conceptos pendientes por clasificar.";
    return;
  }

  for (const concepto of lista) {
    const item = document.createElement("div");
    item.className = "concepto-item";
    item.innerHTML = `
      <div class="titulo">${concepto.tituloLibro} (ISBN ${concepto.isbn}) — ${concepto.nombreConcepto}</div>
      <div class="definicion">${concepto.definicion}</div>
    `;
    item.addEventListener("click", () => {
      conceptoSeleccionado = concepto;
      document.querySelectorAll(".concepto-item").forEach((el) => el.classList.remove("seleccionado"));
      item.classList.add("seleccionado");
      document.getElementById("btnRegistrarSoap").style.display = "inline-block";
      mostrarSoapFault("");
    });
    contenedor.appendChild(item);
  }
}

async function alConsultarPendientes() {
  mostrarSoapFault("");
  const endpoint = document.getElementById("soapEndpoint").value.trim();
  const correo = document.getElementById("correo").value.trim();
  if (!endpoint || !correo) {
    mostrarSoapFault("Indica el endpoint SOAP y tu correo.");
    return;
  }
  localStorage.setItem(CLAVE_LOCALSTORAGE_SOAP, endpoint);

  const resultado = await obtenerConceptosPendientes(endpoint, correo);
  if (!resultado.ok) {
    mostrarSoapFault(`[${resultado.codigo}] ${resultado.mensaje}`);
    return;
  }
  renderConceptosPendientes(resultado.datos);
}

async function alVerProgreso() {
  mostrarSoapFault("");
  const endpoint = document.getElementById("soapEndpoint").value.trim();
  const correo = document.getElementById("correo").value.trim();
  if (!endpoint || !correo) {
    mostrarSoapFault("Indica el endpoint SOAP y tu correo.");
    return;
  }

  const resultado = await obtenerProgresoUsuario(endpoint, correo);
  if (!resultado.ok) {
    mostrarSoapFault(`[${resultado.codigo}] ${resultado.mensaje}`);
    return;
  }
  const p = resultado.datos;
  mostrarSoapOk(
    `Progreso: ${p.totalClasificados} clasificados de ${p.totalConceptos} conceptos (${p.totalPendientes} pendientes).`
  );
}

async function alRegistrarSoap() {
  mostrarSoapFault("");
  const endpoint = document.getElementById("soapEndpoint").value.trim();
  const nombre = document.getElementById("nombre").value.trim();
  const apellido = document.getElementById("apellido").value.trim();
  const correo = document.getElementById("correo").value.trim();

  if (!endpoint || !nombre || !apellido || !correo) {
    mostrarSoapFault("Completa nombre, apellido, correo y el endpoint SOAP.");
    return;
  }
  if (!conceptoSeleccionado) {
    mostrarSoapFault("Selecciona un concepto pendiente de la lista.");
    return;
  }
  if (!ultimaClasificacion || ultimaClasificacion.ganador === "No determinado") {
    mostrarSoapFault(
      "Primero pulsa 'Analizar texto' con una descripcion que contenga pistas claras de IaaS/PaaS/SaaS/FaaS."
    );
    return;
  }

  const resultado = await registrarClasificacion(endpoint, {
    nombre,
    apellido,
    correo,
    isbn: conceptoSeleccionado.isbn,
    idConcepto: conceptoSeleccionado.idConcepto,
    modeloCloud: ultimaClasificacion.ganador,
  });

  if (!resultado.ok) {
    // Aqui es donde la GUI "traduce" un SOAP Fault (p.ej. 409 por
    // clasificacion duplicada) a un mensaje comprensible, sin mostrar
    // SQL ni detalles internos (esos solo quedan en el log del servidor).
    mostrarSoapFault(`[${resultado.codigo}] ${resultado.mensaje}`);
    return;
  }
  mostrarSoapOk(`${resultado.datos.mensaje} (id ${resultado.datos.idClasificacion}).`);
  renderConceptosPendientes([]); // limpia seleccion; el usuario puede volver a consultar pendientes
}

window.addEventListener("DOMContentLoaded", () => {
  const guardada = localStorage.getItem(CLAVE_LOCALSTORAGE_URL);
  if (guardada) document.getElementById("baseUrl").value = guardada;

  const soapGuardado = localStorage.getItem(CLAVE_LOCALSTORAGE_SOAP);
  if (soapGuardado) document.getElementById("soapEndpoint").value = soapGuardado;

  document.getElementById("btnAnalizar").addEventListener("click", async () => {
    await alEnviarFormulario();
    // Guarda el resultado para que "Registrar clasificacion" (modo SOAP)
    // pueda usarlo sin volver a ejecutar las reglas de clasificacion.
    const texto = document.getElementById("texto").value.trim();
    ultimaClasificacion = texto ? clasificarTexto(texto) : null;
  });

  document.getElementById("btnConsultarPendientes").addEventListener("click", alConsultarPendientes);
  document.getElementById("btnVerProgreso").addEventListener("click", alVerProgreso);
  document.getElementById("btnRegistrarSoap").addEventListener("click", alRegistrarSoap);
});
